import os
import pandas as pd
import fnmatch

path = '../data/training_data'

# configfiles = [os.path.join(dirpath, f)
# for dirpath, dirnames, files in os.walk(path)
# for f in fnmatch.filter(files, '*.txt')]

csv_data = []
unique_set = set()

for dirpth, dirnames, files in os.walk(path):
    print(dirpth)
    print(dirnames)
    print(files)
    if not files:
        continue
    if dirpth.split('/')[-1] != 'normal' and dirpth.split('/')[-1] != 'cancer':
        continue
    if dirpth.split('/')[-1] == 'normal':
        for img_file in files:
            csv_data.append([img_file, 0])
            unique_set.add(img_file)
    else:
        for img_file in files:
            csv_data.append([img_file, 1])
            unique_set.add(img_file)
assert len(unique_set) == len(csv_data)

pd = pd.DataFrame(data=csv_data, columns=['image_id', 'label'])
pd.to_csv('train_data.csv', index=False)
